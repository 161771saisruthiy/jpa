package org.cap.demo;

import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class DateAndMessage extends SimpleTagSupport{

	@Override
	public void doTag() throws JspException, IOException {
		 LocalDate localdate=null; 
		 JspWriter out= getJspContext().getOut();
		 StringWriter writer=new StringWriter();
			getJspBody().invoke(writer);	
		 
			 out.println("<h1>" + writer +" "+LocalDate.now()+"</h1>");
	
			 
		 
		 
		
		
	}

	
	
}
