package com.cap.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CustomerJSP {

	public static void main(String[] args) {

		
	/*	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		entityManager.getTransaction().begin();
		Customer customer = new Customer("123A1bd","pankaj","ADHGS78543"); 
	
		//entityManager.getTransaction().commit();
		entityManager.persist(customer);
		
		transaction.commit();
		
		
		// close the entity manager
		entityManager.close();
		entityManagerFactory.close();*/
	

				EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
					
					EntityManager entityManager = emf.createEntityManager();
					
					EntityTransaction transaction =entityManager.getTransaction();
					
					transaction.begin();
					
					Customer customer =new Customer("100","ravi","yujgkvuy136");
					/*Customer customer1 =new Customer(101,"vishwa",2000.00,);
					Customer customer2 =new Customer(102,"kamal",3000.00,);*/
					
					
					
					entityManager.persist(customer); 
					transaction.commit();


	}

	}


